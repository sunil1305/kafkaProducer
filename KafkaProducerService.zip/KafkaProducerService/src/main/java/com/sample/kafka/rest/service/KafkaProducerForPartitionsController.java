package com.sample.kafka.rest.service;

import java.io.IOException;
import java.util.Properties;

import org.apache.log4j.*;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sample.kafka.rest.dto.kafkaJsonMessage;

import kafka.javaapi.producer.Producer;
import kafka.producer.KeyedMessage;
import kafka.producer.ProducerConfig;
@RestController
public class KafkaProducerForPartitionsController

{
	private final org.slf4j.Logger logger=LoggerFactory.getLogger(this.getClass());
	@Autowired
	Environment env;
	
	@RequestMapping(value= "/v1/produce", method=RequestMethod.POST)
	public ResponseEntity<String> produceMessage(@RequestBody String message)
	{
		try {
		com.sample.kafka.rest.dto.kafkaJsonMessage kafkaJsonMessage=jsonHelper(message);
		
		String topicName=kafkaJsonMessage.getTopic();
		logger.debug("topicName----"+topicName);
		logger.debug("Broker"+kafkaJsonMessage.getBroker());
		Properties props=new Properties();
		props.put("metadata.broker.list", kafkaJsonMessage.getBroker());
		props.put("serializer.class", "kafka.serializer.StringEncoder");
		props.put("partitioner.class", "com.sample.kafka.rest.service.KafkaPartitioner");
		props.put("request.required.acks", "1");
		
		ProducerConfig config=new ProducerConfig(props);
		
		Producer<String, String> producer= new Producer<String, String>(config);
		logger.debug("Message"+kafkaJsonMessage.getMessages());
		logger.debug("Broker"+kafkaJsonMessage.getBroker());
		logger.debug("Key"+kafkaJsonMessage.getKey());
		for(String load:kafkaJsonMessage.getMessages())
		{
			logger.debug("load---");
			KeyedMessage<String, String> data= new KeyedMessage<String, String>(topicName,kafkaJsonMessage.getKey(),load);
			producer.send(data);
		}
		producer.close();
		
		return new ResponseEntity<String>(getResponseObject("SUCCESS","Message Produced Successfully"), HttpStatus.OK);
		
	}catch(Exception ex)
	{
		ex.printStackTrace();
		logger.error("ERROR-001-IO AddressException: "+ex.getMessage());
		return new ResponseEntity<String>(getResponseObject("ERROR-001-IO AddressException", ex.getMessage()),HttpStatus.BAD_REQUEST);
	}
	}
	private String getResponseObject(String status, String message)
	{
		String responseObject="{\n" + "    \"Status\": \"" + status + "\",\n" + "     \"Message\": \"" + message 
				+"\"\n" + "}";
		
		return responseObject;
	}
	private kafkaJsonMessage jsonHelper(String inputString) throws JsonMappingException, JsonParseException, IOException
	{
		kafkaJsonMessage kafkaJsonMessage=new kafkaJsonMessage();
		ObjectMapper mapper=new ObjectMapper();
		kafkaJsonMessage=mapper.readValue(inputString, kafkaJsonMessage.class);
		return kafkaJsonMessage;
		
	}
}