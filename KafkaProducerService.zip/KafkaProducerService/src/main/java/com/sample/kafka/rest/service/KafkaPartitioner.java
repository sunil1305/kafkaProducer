package com.sample.kafka.rest.service;

import kafka.producer.Partitioner;
import kafka.utils.VerifiableProperties;

public class KafkaPartitioner implements Partitioner{
	
	public KafkaPartitioner(VerifiableProperties props)
	{
		
	}
    public int partition(Object key, int numPartition)
    {
    	int partition=0;
    	
    	String stringKey=(String) key;
    	
    	if(stringKey==null || stringKey.length()==0)
    	{
    		partition=0;
    	}
    	else
    	{
    		partition=Character.getNumericValue(stringKey.charAt(stringKey.length()-1));
    	}
    	return partition;
    }
}
