package com.sample.kafka.rest.dto;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Generated;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Getter;
import lombok.Setter;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Generated("org.jsonschema2pojo")
@JsonPropertyOrder({
	"id",
	"broker",
	"key",
	"topic",
	"messages"
})
@Getter
@Setter
public class kafkaJsonMessage
{
	@JsonProperty("id")
	private Integer id;
	
	@JsonProperty("broker")
	private String broker;
	
	@JsonProperty("key")
	private String key;
	
	@JsonProperty("topic")
	private String topic;
	
	@JsonProperty("messages")
	private List<String> messages=new ArrayList<String>();
	
	
	@JsonIgnore
	private Map<String,Object> additionalProperties=new HashMap<String, Object>();
	
	
	
	
	

}