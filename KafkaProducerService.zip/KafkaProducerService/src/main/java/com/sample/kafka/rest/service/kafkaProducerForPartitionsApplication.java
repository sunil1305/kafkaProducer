package com.sample.kafka.rest.service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class kafkaProducerForPartitionsApplication
{
	public static void main(String args[])
	{
		SpringApplication.run(kafkaProducerForPartitionsApplication.class, args);
	}
}